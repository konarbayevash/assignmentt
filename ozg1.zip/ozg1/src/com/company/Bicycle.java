package com.company;

public class Bicycle implements Vehicle {
    private double stamina = 500;

    public Bicycle(){

    }

    public Bicycle(double stamina) {
        this.stamina = stamina;
    }

    public void run(double time) {
        stamina -= time;

    }
    public void takeBreak(double time) {
        System.out.println("stamina will decrease by :" + time);
    }

    public String toString(){
        return "Bicycle{" +
                "stamina=" + stamina +
                '}';
    }
}
