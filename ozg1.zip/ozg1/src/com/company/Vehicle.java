package com.company;

public interface Vehicle {

    default void run(double time){
        System.out.println("stamina will decrease by :" + time);
    }

    void takeBreak(double time);
}
