package com.company;



import java.lang.reflect.InvocationTargetException;

public class Main {
    public static void main(String[] args) throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {

        Car c = new Car();
        Bicycle bi = new Bicycle();

        Vehicle a = new Vehicle() {

            public void takeBreak(double time) {
                System.out.println("stamina will decrease by :" + time);
            }


        };
        Car car = Car.class.getConstructor(double.class).newInstance(5);
        Bicycle velik = Bicycle.class.getConstructor(double.class).newInstance(10);
        System.out.println(car);
        System.out.println(velik);
    }
}
