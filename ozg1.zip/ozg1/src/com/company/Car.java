package com.company;

public class Car implements Vehicle {
    private double stamina;

    public Car(double stamina) {
        this.stamina = stamina;
    }
    public Car(){

    }

    public void run(double quantity) {
        stamina -= quantity;
        System.out.println("Left stamina :" + stamina);
    }

    public void takeBreak(double quantity) {
        stamina += quantity;
        System.out.println("Left Stamina :" + stamina);
    }



    public String toString(){
        return "Car{" +
                "stamina=" + stamina +
                '}';
    }
}

